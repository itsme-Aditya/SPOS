# Python program for SJF Preemptive (Shortest Remaining Time First) Scheduling

# Function to find the waiting time for all processes
def calculate_waiting_time(at, bt, n):
    remaining_time = bt[:]  # Copy of burst times to store remaining burst times
    wt = [0] * n            # Array to store waiting times
    complete = 0            # Number of processes completed
    t = 0                   # Current time
    min_remaining = float('inf')  # Minimum remaining time
    shortest = 0            # Index of the process with the shortest remaining time
    check = False

    # Process until all processes are completed
    while complete != n:
        # Find process with the minimum remaining time at the current time
        for i in range(n):
            if at[i] <= t and remaining_time[i] < min_remaining and remaining_time[i] > 0:
                min_remaining = remaining_time[i]
                shortest = i
                check = True

        if not check:  # If no process is ready to execute, move forward in time
            t += 1
            continue

        # Reduce remaining time by 1 for the shortest process
        remaining_time[shortest] -= 1
        min_remaining = remaining_time[shortest]

        # If a process gets completely executed
        if remaining_time[shortest] == 0:
            min_remaining = float('inf')  # Reset minimum for next process selection
            complete += 1
            check = False

            # Calculate finish time and waiting time for the completed process
            finish_time = t + 1
            wt[shortest] = finish_time - at[shortest] - bt[shortest]
            if wt[shortest] < 0:
                wt[shortest] = 0  # Waiting time cannot be negative

        # Increment time after each unit of execution
        t += 1

    return wt

# Function to calculate turn around time
def calculate_turnaround_time(at, bt, wt, n):
    tat = [0] * n  # Array to store turnaround times
    for i in range(n):
        tat[i] = bt[i] + wt[i]
    return tat

# Function to print the SJF preemptive scheduling result
def sjf_preemptive(at, bt):
    n = len(at)
    wt = calculate_waiting_time(at, bt, n)  # Calculate waiting times
    tat = calculate_turnaround_time(at, bt, wt, n)  # Calculate turnaround times

    # Print process details
    print("P.No.\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\tCompletion Time")
    for i in range(n):
        ct = at[i] + tat[i]  # Completion time is arrival time + turnaround time
        print(f"{i + 1}\t\t{at[i]}\t\t{bt[i]}\t\t{wt[i]}\t\t{tat[i]}\t\t{ct}")

# Driver code
if __name__ == "__main__":
    at = [0, 1, 2, 3]  # Arrival times
    bt = [7, 4, 1, 4]  # Burst times
    sjf_preemptive(at, bt)
