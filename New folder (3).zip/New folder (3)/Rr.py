# Python program for Round Robin Scheduling with Arrival Time

# Function to find the waiting time for all processes
def calculate_waiting_time(processes, n, at, bt, wt, quantum):
    remaining_time = bt[:]  # Copy of burst times to store remaining burst times
    t = 0  # Current time
    queue = []  # Queue to store processes based on arrival and remaining time
    complete = 0  # Number of completed processes
    arrived = [False] * n  # To keep track of processes that have arrived
    
    while complete < n:
        # Add processes that have arrived to the queue
        for i in range(n):
            if at[i] <= t and not arrived[i] and remaining_time[i] > 0:
                queue.append(i)
                arrived[i] = True
        
        # If the queue is empty, just move forward in time
        if not queue:
            t += 1
            continue

        # Get the first process from the queue
        current = queue.pop(0)

        # Process it for quantum time or its remaining time, whichever is smaller
        if remaining_time[current] > quantum:
            t += quantum
            remaining_time[current] -= quantum
        else:
            t += remaining_time[current]
            wt[current] = t - at[current] - bt[current]  # Waiting time is current time - arrival time - burst time
            remaining_time[current] = 0  # Process is complete
            complete += 1

        # If the process still has remaining time, add it back to the queue
        if remaining_time[current] > 0:
            queue.append(current)
            
# Function to calculate turn around time
def calculate_turnaround_time(n, bt, wt, tat):
    for i in range(n):
        tat[i] = bt[i] + wt[i]  # Turnaround time is burst time + waiting time

# Function to perform Round Robin scheduling and print results
def round_robin_with_arrival(processes, n, at, bt, quantum):
    wt = [0] * n  # Waiting time for each process
    tat = [0] * n  # Turnaround time for each process

    # Calculate waiting times
    calculate_waiting_time(processes, n, at, bt, wt, quantum)

    # Calculate turnaround times
    calculate_turnaround_time(n, bt, wt, tat)

    # Display process details
    print("P.No.\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"{processes[i]}\t\t{at[i]}\t\t{bt[i]}\t\t{wt[i]}\t\t{tat[i]}")

# Driver code
if __name__ == "__main__":
    processes = [1, 2, 3, 4]  # Process IDs
    arrival_time = [0, 1, 2, 3]  # Arrival times
    burst_time = [5, 3, 8, 6]  # Burst times
    quantum = 3  # Time quantum

    round_robin_with_arrival(processes, len(processes), arrival_time, burst_time, quantum)
