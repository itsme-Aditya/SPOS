# Python program for Priority Scheduling (Non-preemptive)

# Function to find the waiting time for all processes
def calculate_waiting_time(n, at, bt, priority, wt):
    # Sort processes by arrival time and priority (higher priority first)
    processes = sorted(range(n), key=lambda x: (at[x], priority[x]))

    # First process starts execution immediately at its arrival time
    wt[processes[0]] = 0
    time = at[processes[0]] + bt[processes[0]]

    # Calculate waiting time for the rest of the processes
    for i in range(1, n):
        process = processes[i]

        # Wait if the process arrives after the current time
        if at[process] > time:
            time = at[process]

        # Waiting time is the current time minus arrival time
        wt[process] = time - at[process]

        # Update the current time with the burst time of the current process
        time += bt[process]

# Function to calculate turn around time
def calculate_turnaround_time(n, bt, wt, tat):
    for i in range(n):
        tat[i] = bt[i] + wt[i]  # Turnaround time is burst time + waiting time

# Function to perform Priority Scheduling and print results
def priority_scheduling(processes, n, at, bt, priority):
    wt = [0] * n  # Waiting time for each process
    tat = [0] * n  # Turnaround time for each process

    # Calculate waiting times
    calculate_waiting_time(n, at, bt, priority, wt)

    # Calculate turnaround times
    calculate_turnaround_time(n, bt, wt, tat)

    # Display process details
    print("P.No.\tArrival Time\tBurst Time\tPriority\tWaiting Time\tTurnaround Time")
    for i in range(n):
        print(f"{processes[i]}\t\t{at[i]}\t\t{bt[i]}\t\t{priority[i]}\t\t{wt[i]}\t\t{tat[i]}")

# Driver code
if __name__ == "__main__":
    processes = [1, 2, 3, 4]  # Process IDs
    arrival_time = [0, 1, 2, 3]  # Arrival times
    burst_time = [10, 5, 8, 6]  # Burst times
    priority = [2, 1, 3, 2]  # Priority levels (lower number = higher priority)

    priority_scheduling(processes, len(processes), arrival_time, burst_time, priority)
