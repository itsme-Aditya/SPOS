from picamera import PiCamera
from time import sleep

# Initialize the PiCamera
camera = PiCamera()

try:
    # Start camera preview
    camera.start_preview()
    print("Camera preview started. Adjust your subject.")

    # Wait for 5 seconds to allow camera adjustments (optional)
    sleep(5)

    # Capture the image
    camera.capture('/home/pi/captured_image.jpg')
    print("Image captured and saved as 'captured_image.jpg'.")

    # Stop camera preview
    camera.stop_preview()

except KeyboardInterrupt:
    print("Program interrupted by the user.")

finally:
    # Ensure camera resources are released
    camera.close()
    print("Camera resources released.")
