slot = [100, 200, 400, 500, 600]
processes = [240, 150, 300, 370]
allocate = [None] * 10

def first_fit():
    print("FIRST FIT")
    for i in range (0, len(processes)):
        for j in range (0, len(slot)):
            if processes[i] <= slot[j]:
                allocate[j] = i
                slot[j] = 0
                break
    print("\nALLOCATION:\nSLOT:\t\tPROCESS:")
    for k in range (0, len(slot)):
        if allocate[k] != None:
            print(f"Slot {k + 1}:\t\tP{allocate[k] + 1}")
        else:
            print(f"Slot {k + 1}:\t\t{allocate[k]}")

def best_fit():
    print("BEST FIT")
    for i in range (len(processes)):
        diff = 999
        worst_slot = -1
        for j in range (len(slot)):
            if (processes[i] <= slot[j]) and (slot[j] - processes[i] <= diff):
                worst_slot = j
                diff = slot[j] - processes[i]
        if worst_slot != -1:
            allocate[worst_slot] = i
            slot[worst_slot] = 0
                
    print("\nALLOCATION:\nSLOT:\t\tPROCESS:")
    for k in range (0, len(slot)):
        if allocate[k] != None:
            print(f"Slot {k + 1}:\t\tP{allocate[k] + 1}")
        else:
            print(f"Slot {k + 1}:\t\t{allocate[k]}")

def worst_fit():
    print("WORST FIT")
    for i in range (len(processes)):
        diff = -1
        worst_slot = -1
        for j in range (len(slot)):
            if (processes[i] <= slot[j]) and (slot[j] - processes[i] >= diff):
                worst_slot = j
                diff = slot[j] - processes[i]
        if worst_slot != -1:
            allocate[worst_slot] = i
            slot[worst_slot] = 0
                
    print("\nALLOCATION:\nSLOT:\t\tPROCESS:")
    for k in range (0, len(slot)):
        if allocate[k] != None:
            print(f"Slot {k + 1}:\t\tP{allocate[k] + 1}")
        else:
            print(f"Slot {k + 1}:\t\t{allocate[k]}")

def next_fit():                          #slot = [100, 200, 400, 500, 600]
                                         #processes = [240, 150, 300, 370]
    print("NEXT FIT")
    j = 0
    for i in range (0, len(processes)):
        count = 0
        while count < len(slot):
            if processes[i] <= slot[j]:
                allocate[j] = i
                slot[j] = 0
                break
            j = (j + 1) % len(slot)
            count += 1
    print("\nALLOCATION:\nSLOT:\t\tPROCESS:")
    for k in range (0, len(slot)):
        if allocate[k] != None:
            print(f"Slot {k + 1}:\t\tP{allocate[k] + 1}")
        else:
            print(f"Slot {k + 1}:\t\t{allocate[k]}")

#first_fit()
#best_fit()
#worst_fit()
next_fit()
